const CACHE_NAME = 'booktok-v1';if ('serviceWorker' in navigator) {




















});  );      .then(response => response || fetch(event.request))    caches.match(event.request)  event.respondWith(self.addEventListener('fetch', event => {});  );      .then(cache => cache.addAll(urlsToCache))    caches.open(CACHE_NAME)  event.waitUntil(self.addEventListener('install', event => {];  '/manifest.json'  '/script.js',  '/index.html',  '/',const urlsToCache = [  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(registration => console.log('SW registered'))
      .catch(error => console.log('SW registration failed'));
  });
}