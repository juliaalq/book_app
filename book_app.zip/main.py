from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
import openai
import os

# Set your OpenAI API key here
openai.api_key = os.getenv('OPENAI_API_KEY')  # Or hardcode for testing, but use env var

class BookRecommendationApp(App):
    def build(self):
        self.layout = BoxLayout(orientation='vertical')
        
        self.question_label = Label(text="AI Question: Loading...")
        self.layout.add_widget(self.question_label)
        
        self.answer_input = TextInput(hint_text="Your answer")
        self.layout.add_widget(self.answer_input)
        
        self.submit_button = Button(text="Submit Answer")
        self.submit_button.bind(on_press=self.get_recommendation)
        self.layout.add_widget(self.submit_button)
        
        self.recommendation_label = Label(text="")
        self.layout.add_widget(self.recommendation_label)
        
        self.generate_question()
        
        return self.layout
    
    def generate_question(self):
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": "Generate a personalized question for book recommendations based on reading trends."}]
            )
            question = response.choices[0].message.content
            self.question_label.text = f"AI Question: {question}"
        except Exception as e:
            self.question_label.text = f"Error generating question: {str(e)}"
    
    def get_recommendation(self, instance):
        answer = self.answer_input.text
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "user", "content": f"Based on the answer '{answer}' to the question '{self.question_label.text}', recommend some books."}
                ]
            )
            recommendation = response.choices[0].message.content
            self.recommendation_label.text = f"Recommendation: {recommendation}"
        except Exception as e:
            self.recommendation_label.text = f"Error getting recommendation: {str(e)}"

if __name__ == '__main__':
    BookRecommendationApp().run()