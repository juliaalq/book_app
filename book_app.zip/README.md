# BookTok Quiz Mobile App

A React Native mobile app for viral book recommendations using AI.

## Features
- TikTok-style questions
- AI-powered recommendations
- Catchy visuals with animations
- PWA fallback

## Backend Setup (Python/Flask)
1. Install Python 3.8+ (you have 3.13, which works).
2. In the project folder, run: `pip install -r requirements.txt`
3. Create a `.env` file with: `OPENAI_API_KEY=your_key_here`
4. Run the server: `python server.py`
5. Server runs at http://localhost:3000

## Mobile App Setup
1. Go to https://snack.expo.dev
2. Create a new Snack.
3. Paste the App.js code.
4. Install dependencies: expo-linear-gradient, @expo/vector-icons.
5. Replace 'https://your-backend-url' with your backend URL (localhost:3000 for local testing, or deployed URL).
6. Run on device: Scan QR code with Expo Go app.

## Deployment
- Backend: Deploy to PythonAnywhere, Heroku, or Railway (free tier available).
- Mobile: Use EAS Build (Expo) to create APK/IPA, publish to app stores.

## Monetization
Publish to app stores, charge for download or in-app purchases.