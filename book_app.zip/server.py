from flask import Flask, jsonify, request, send_from_directory
from openai import OpenAI
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__, static_folder='public', static_url_path='')
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

@app.route('/')
def index():
    return send_from_directory('public', 'index.html')

@app.route('/api/question', methods=['GET'])
def get_question():
    try:
        response = client.chat.completions.create(
            model='gpt-3.5-turbo',
            messages=[{'role': 'user', 'content': 'Generate a fun, viral TikTok-style question to help recommend books based on user preferences and reading trends.'}]
        )
        question = response.choices[0].message.content
        return jsonify({'question': question})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/recommendation', methods=['POST'])
def get_recommendation():
    try:
        data = request.get_json()
        answer = data.get('answer')
        question = data.get('question')
        
        response = client.chat.completions.create(
            model='gpt-3.5-turbo',
            messages=[{'role': 'user', 'content': f"Based on the answer '{answer}' to the question '{question}', recommend some books."}]
        )
        recommendation = response.choices[0].message.content
        return jsonify({'recommendation': recommendation})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('public', path)

if __name__ == '__main__':
    app.run(debug=True, port=3000)