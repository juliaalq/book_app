<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->
- [x] Verify that the copilot-instructions.md file in the .github directory is created.

- [x] Clarify Project Requirements

- [x] Scaffold the Project

- [x] Customize the Project
	<!-- Basic AI features added to main.py -->

- [x] Install Required Extensions

- [x] Compile the Project
	<!-- Dependencies installed -->

- [x] Create and Run Task
	<!-- Task created for running the app -->

- [x] Launch the Project
	<!-- App launched successfully -->

- [x] Ensure Documentation is Complete
	<!-- README.md created, instructions cleaned -->

- Work through each checklist item systematically.
- Keep communication concise and focused.
- Follow development best practices.