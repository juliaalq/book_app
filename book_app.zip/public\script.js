document.addEventListener('DOMContentLoaded', () => {
    // Register service worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js');
    }
    const questionDiv = document.getElementById('question');
    const answerInput = document.getElementById('answer');
    const submitButton = document.getElementById('submit');
    const recommendationDiv = document.getElementById('recommendation');

    // Load initial question
    fetch('/api/question')
        .then(response => response.json())
        .then(data => {
            questionDiv.innerHTML = `<i class="fas fa-question-circle icon"></i>${data.question}`;
        })
        .catch(error => {
            questionDiv.textContent = `Error: ${error.message}`;
        });

    submitButton.addEventListener('click', () => {
        const answer = answerInput.value;
        const question = questionDiv.textContent.replace(/<[^>]*>/g, ''); // Remove icons for API

        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin icon"></i>Loading...';

        fetch('/api/recommendation', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ answer, question })
        })
        .then(response => response.json())
        .then(data => {
            recommendationDiv.innerHTML = `<i class="fas fa-star icon"></i>${data.recommendation}`;
            recommendationDiv.style.display = 'block';
            // Add confetti effect (simple animation)
            createConfetti();
        })
        .catch(error => {
            recommendationDiv.textContent = `Error: ${error.message}`;
            recommendationDiv.style.display = 'block';
        })
        .finally(() => {
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="fas fa-magic icon"></i>Get My Book Rec!';
        });
    });

    function createConfetti() {
        for (let i = 0; i < 50; i++) {
            const confetti = document.createElement('div');
            confetti.style.position = 'absolute';
            confetti.style.width = '10px';
            confetti.style.height = '10px';
            confetti.style.background = `hsl(${Math.random() * 360}, 100%, 50%)`;
            confetti.style.left = Math.random() * window.innerWidth + 'px';
            confetti.style.top = '-10px';
            confetti.style.animation = `fall ${Math.random() * 3 + 2}s linear`;
            document.body.appendChild(confetti);
            setTimeout(() => document.body.removeChild(confetti), 5000);
        }
    }

    // Add CSS for confetti animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fall {
            to { transform: translateY(100vh); }
        }
    `;
    document.head.appendChild(style);
});