import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

export default function App() {
  const [question, setQuestion] = useState('Loading viral question...');
  const [answer, setAnswer] = useState('');
  const [recommendation, setRecommendation] = useState('');
  const [loading, setLoading] = useState(false);
  const fadeAnim = new Animated.Value(0);

  useEffect(() => {
    fetchQuestion();
  }, []);

  const fetchQuestion = async () => {
    try {
      const response = await fetch('https://your-backend-url/api/question'); // Replace with your deployed backend URL
      const data = await response.json();
      setQuestion(data.question);
    } catch (error) {
      setQuestion('Error loading question');
    }
  };

  const getRecommendation = async () => {
    if (!answer.trim()) {
      Alert.alert('Error', 'Please enter an answer');
      return;
    }
    setLoading(true);
    try {
      const response = await fetch('https://your-backend-url/api/recommendation', { // Replace with your deployed backend URL
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answer, question }),
      });
      const data = await response.json();
      setRecommendation(data.recommendation);
      Animated.timing(fadeAnim, { toValue: 1, duration: 1000, useNativeDriver: true }).start();
      // Add confetti logic here if possible
    } catch (error) {
      Alert.alert('Error', error.message);
    }
    setLoading(false);
  };

  return (
    <LinearGradient colors={['#667eea', '#764ba2']} style={styles.container}>
      <Text style={styles.title}>
        <Ionicons name="book" size={24} color="white" /> BookTok Quiz
      </Text>
      <View style={styles.questionBox}>
        <Text style={styles.question}>
          <Ionicons name="help-circle" size={20} color="white" /> {question}
        </Text>
      </View>
      <TextInput
        style={styles.input}
        placeholder="Your answer here..."
        value={answer}
        onChangeText={setAnswer}
      />
      <TouchableOpacity style={styles.button} onPress={getRecommendation} disabled={loading}>
        <Text style={styles.buttonText}>
          {loading ? <Ionicons name="refresh" size={20} color="white" /> : <Ionicons name="magic" size={20} color="white" />} 
          {loading ? 'Loading...' : 'Get My Book Rec!'}
        </Text>
      </TouchableOpacity>
      {recommendation ? (
        <Animated.View style={[styles.recommendationBox, { opacity: fadeAnim }]}>
          <Text style={styles.recommendation}>
            <Ionicons name="star" size={20} color="white" /> {recommendation}
          </Text>
        </Animated.View>
      ) : null}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
    textAlign: 'center',
  },
  questionBox: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    width: '100%',
  },
  question: {
    fontSize: 18,
    color: 'white',
    textAlign: 'center',
  },
  input: {
    width: '100%',
    padding: 15,
    backgroundColor: 'white',
    borderRadius: 25,
    fontSize: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  button: {
    backgroundColor: 'rgba(255,107,107,0.8)',
    padding: 15,
    borderRadius: 25,
    width: '100%',
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  recommendationBox: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    padding: 20,
    borderRadius: 10,
    width: '100%',
  },
  recommendation: {
    fontSize: 16,
    color: 'white',
    textAlign: 'center',
  },
});